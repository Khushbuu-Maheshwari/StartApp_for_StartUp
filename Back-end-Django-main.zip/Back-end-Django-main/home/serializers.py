from rest_framework import serializers
from .models import *

class UserRegSerializer(serializers.ModelSerializer):
    class Meta:
        model=UserAccount
        fields=['email','password','is_active','is_ind','is_org','email_token']

    def validate(self,data):
        if UserAccount.objects.filter(email=data['email']).count()>0:
            raise serializers.ValidationError("Email already exists.")
        
        return data

class Reg_ind_Serializer(serializers.ModelSerializer):

    class Meta:
        model = IndProfile
        # exclude = ['password']
        fields = '__all__'
        # fields = ['firstname', 'lastname', 'email','age','username','password']
        
    def validate(self, data):
        
        if data['age']<18:
            raise serializers.ValidationError({'error': 'age cant be less than 18'})
        
        if data['firstname']:
            for n in data['firstname']:
                if n.isdigit():
                    raise serializers.ValidationError({'error': "firstname cannot be numeric"})
                
        if data['lastname']:
            for n in data['lastname']:
                if n.isdigit():
                    raise serializers.ValidationError({'error': "lastname cannot be numeric"})

        return data
    

class Reg_org_Serializer(serializers.ModelSerializer):

    class Meta:
        model = OrgProfile
        # exclude = [ 'id' ]
        fields = '__all__'
        # fields = ['companyName', 'email','YearOfEstablishment','username','password']

    def validate(self, data):
        
        if data['CEOName']:
            for n in data['CEOName']:
                if n.isdigit():
                    raise serializers.ValidationError({'error': "CEO Name cannot be numeric"})
                
        return data
    
class passwordValidationSerializer(serializers.ModelSerializer):
    class Meta:
        model=UserAccount
        fields=['password']

    def validate(self,data):
        password=data['password']

        if len(password)<8:
            raise serializers.ValidationError("Password must have atleast 8 Charaters")
        
        is_num=False
        is_alp=False
        is_special=False
        for n in password:
            if n.isdigit():
                is_num=True

        if not is_num:
            raise serializers.ValidationError("Password must contain numeric charater")
        
        for n in password:
            if n.isalpha():
                is_alp=True

        if not is_alp:
            raise serializers.ValidationError("Password must contain alphabetic charater")
        
        for n in password:
            if n=='*' or n=='#' or n=='!' or n=='&':
                is_special=True

        if not is_special:
            raise serializers.ValidationError("Password must contain either of *,#,!,& charater")
        
        return data