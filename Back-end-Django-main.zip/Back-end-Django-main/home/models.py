from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.contrib.auth.models import AbstractUser

class UserAccount(AbstractUser):
  email=models.EmailField(max_length=255,unique=True)
  password=models.CharField(max_length=255)
  is_ind=models.BooleanField(default=False)
  is_org=models.BooleanField(default=False)
  is_active=models.BooleanField(default=False)
  email_token=models.CharField(max_length=200,null=True)
  username=None

  USERNAME_FIELD='email'
  REQUIRED_FIELDS=[]

class IndProfile(models.Model):
  STATUS = (
    ('Bachelors','Bachelors'),
    ('Masters','Master'),
    ('Ph.D','Ph.D'),
  )
  firstname = models.CharField(max_length=200, null=True)
  lastname = models.CharField(max_length=200, null=True)
  phone_number = PhoneNumberField()
  college_name = models.CharField(max_length=200, null=True)
  country = models.CharField(max_length=200, null=True)
  age = models.IntegerField(null=True)
  highest_qualifications = models.CharField(max_length=200, null=True, choices=STATUS)
  email=models.EmailField(max_length=255,unique=True,null=True)

class OrgProfile(models.Model):
  companyName = models.CharField(max_length=200, null=True)
  email = models.EmailField(max_length=255, null=True)
  phoneNumber = PhoneNumberField()
  CEOName = models.CharField(max_length=200, null=True)
  HeadquartersLoc = models.CharField(max_length=200, null=True)
  YearOfEstablishment = models.IntegerField(null=True)
  user=models.ForeignKey(UserAccount,on_delete=models.CASCADE,null=True)

    