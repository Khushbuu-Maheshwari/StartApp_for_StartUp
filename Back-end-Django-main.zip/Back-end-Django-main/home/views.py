from django.shortcuts import render
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from .models import *
from .serializers import *
from django.contrib.auth.hashers import make_password, check_password
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
import uuid
from .utils import *

# Create your views here.

@api_view(['GET'])
@permission_classes([IsAuthenticated])
@authentication_classes([JWTAuthentication])
def home_ind(request):
    reg_ind_obj =  IndProfile.objects.all()
    serializer = Reg_ind_Serializer(reg_ind_obj, many=True)

    return Response({'status' : 200, 'payload' : serializer.data})

@api_view(['POST'])
def reg_page_ind(request):
    data = request.data

    serializer_password=passwordValidationSerializer(data=request.data)

    if not serializer_password.is_valid():
        return Response({'status' : 403, 'errors' : serializer_password.errors, 'message' : 'Something went wrong'})
    
    data['password'] = make_password(data['password'])
    request.data['email_token']=str(uuid.uuid4)
    serializer_user = UserRegSerializer(data = request.data)

    if not serializer_user.is_valid():
        return Response({'status' : 403, 'errors' : serializer_user.errors, 'message' : 'Something went wrong'})
    
    serializer_profile = Reg_ind_Serializer(data = request.data)

    if not serializer_profile.is_valid():
        return Response({'status' : 403, 'errors' : serializer_profile.errors, 'message' : 'Something went wrong'})

    serializer_user.save()
    serializer_profile.save()

    send_mail(data['email'],serializer_user.email_token)

    return Response({'status' : 200, 'payload' : data, 'message' : "you sent"})

@api_view(['GET'])
@permission_classes([IsAuthenticated])
@authentication_classes([JWTAuthentication])
def home_org(request):
    reg_ind_obj =  OrgProfile.objects.all()
    serializer = Reg_org_Serializer(reg_ind_obj, many=True)

    return Response({'status' : 200, 'payload' : serializer.data})


@api_view(['POST'])
def reg_page_org(request):
    data = request.data

    serializer_password=passwordValidationSerializer(data=request.data)

    if not serializer_password.is_valid():
        return Response({'status' : 403, 'errors' : serializer_password.errors, 'message' : 'Something went wrong'})
    
    data['password'] = make_password(data['password'])
    serializer_user = UserAccount(data = request.data)

    if not serializer_user.is_valid():
        return Response({'status' : 403, 'errors' : serializer_user.errors, 'message' : 'Something went wrong'})

    serializer_profile = Reg_org_Serializer(data = request.data)

    if not serializer_profile.is_valid():
        return Response({'status' : 403, 'errors' : serializer_profile.errors, 'message' : 'Something went wrong'})

    serializer_user.save()
    serializer_profile.save()

    return Response({'status' : 200, 'payload' : data, 'message' : "you sent"})


#left to check the functionality

@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
@authentication_classes([JWTAuthentication])
def delete_stud_ind(request, id):
    try:
        data_obj_user_account = UserAccount.get(id = id)
        email=data_obj_user_account.email
        data_obj_user_account.delete()
        data_obj_profile=IndProfile.get(email=email)
        data_obj_profile.delete()
        return Response({'status': 200, 'message': 'deleted'})
    
    except Exception as E:
        return Response({'status' : 403, 'message' : 'invalid id'})
    
@api_view(['DELETE'])
@permission_classes([IsAuthenticated])
@authentication_classes([JWTAuthentication])
def delete_stud_org(request, id):
    try:
        data_obj_user_account = UserAccount.get(id = id)
        email=data_obj_user_account.email
        data_obj_user_account.delete()
        data_obj_profile=OrgProfile.get(email=email)
        data_obj_profile.delete()
        return Response({'status': 200, 'message': 'deleted'})
    
    except Exception as E:
        return Response({'status' : 403, 'message' : 'invalid id'})
    
@api_view(['POST'])
def login_page(request):
    data=request.data
    print(request)
    if UserAccount.objects.filter(email=request.data['email']).count()==0:
        return Response({'status' : 403, 'errors' : 'No such email', 'message' : 'Something went wrong'})
    
    user=UserAccount.objects.get(email=data['email'])
    if not check_password(data['password'],user.password):
        return Response({'status' : 403, 'errors' : 'Incorrect Password', 'message' : 'Something went wrong'})
    
    refresh=RefreshToken.for_user(user)

    return Response({"token":str(refresh),"access":str(refresh.access_token)})

def verify(request,token):
    try:
        obj=UserAccount.objects.get(email_token=token)
        obj.is_active=True
        obj.save()
        return Response({'status' : 200, 'message' : 'Account Verified'})
    
    except Exception as e:
        return Response({'status' : 403, 'message' : 'Invalid Token'})