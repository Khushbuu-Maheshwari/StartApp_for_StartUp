from django.contrib import admin
from django.urls import path, include
from .views import *

urlpatterns = [
    path('individual/', home_ind),
    path('organization/',home_org),
    path('ind/register/',reg_page_ind),
    path('org/register/', reg_page_org),
    path('login/',login_page),
    path('',verify)
]