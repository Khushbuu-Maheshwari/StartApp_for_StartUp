# IT314 Software Engineering

## Group 27

### Course Project Back-end Repository

To run in production environment follow:
1.  ```json
     npm install
     ```
2.  ```json
     npm run start
     ```
