# IT314 Software Engineering

## Group 27

### Course Project Labs and Documentation Repository

# Labs, Diagrams and Documentations

This is the main repository for all the lab submissions for the course IT314-Software Engineering. It also contains various design analysis diagrams and documentations.  

# Contents 
1. Concept Poster
2. Requirements Poster
3. Non-Functional Requirements
4. Functional Requiremets
5. Concept Map
6. User Stories
7. Use Case Diagram
8. Use Case Documentation
9. Sequence Diagram
10. Activity Diagram
11. Class Diagram
12. Future Scope
