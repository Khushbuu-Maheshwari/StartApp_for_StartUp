export const API_URL = "https://start-app-for-startups-group27.up.railway.app";

// export const API_URL = "http://localhost:5000";