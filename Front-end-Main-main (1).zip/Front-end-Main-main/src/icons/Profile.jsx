import React from 'react';
import Image from '../assets/images/Profile.svg';

function Profile() {
	return (
		<img src={Image} alt="Profile" />
	);
}

export default Profile;