import React from 'react';

function Logo() {
    return <img src="https://i.imgur.com/Bo0baD1.png" alt="Logo" style={{ width: '400px', height: '400px' }} />;
}

export default Logo;
