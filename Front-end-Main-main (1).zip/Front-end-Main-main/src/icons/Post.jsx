import React from 'react';
import Image from '../assets/images/Post.svg';

function Post() {
    return (
        <img src={Image} alt="Post" />
    );
}

export default Post;