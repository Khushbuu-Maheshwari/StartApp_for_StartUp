import React from 'react';
import Image from '../assets/images/Chat.svg';

function Chat() {
	return (
		<img src={Image} alt="Chat" />
	);
}

export default Chat;