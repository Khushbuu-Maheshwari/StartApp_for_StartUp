import React from 'react';
import Image from '../assets/images/IdeaSharing.svg';

function IdeaSharing() {
	return (
		<img src={Image} alt="IdeaSharing" />
	);
}

export default IdeaSharing;