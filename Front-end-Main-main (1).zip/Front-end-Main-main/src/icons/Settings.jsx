import React from 'react';
import Image from '../assets/images/Settings.svg';

function Settings() {
	return (
		<img src={Image} alt="Settings" />
	);
}

export default Settings;