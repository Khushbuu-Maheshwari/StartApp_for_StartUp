import React from 'react';
import Image from '../assets/images/Updates.svg';

function Updates() {
	return (
		<img src={Image} alt="Updates" />
	);
}

export default Updates;