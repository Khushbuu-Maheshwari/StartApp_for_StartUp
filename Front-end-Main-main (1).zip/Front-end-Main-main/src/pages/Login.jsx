import React from 'react';
import '../components/Register.css';
import LoginContainer from '../components/LoginContainer';
function App() {
  return (
    <div className="App">
      <LoginContainer />
    </div>
  );
}

export default App;