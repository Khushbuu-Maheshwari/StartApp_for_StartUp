import React from 'react';
import '../components/Register.css';
import RegisterContainer from '../components/RegisterContainer';
function App() {
  return (
    <div className="App">
     <RegisterContainer/>
    </div>
  );
}

export default App;