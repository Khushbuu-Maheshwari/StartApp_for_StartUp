# IT314 Software Engineering

## Group 27

### Course Project UI/UX Repository

Link to the figma document:


https://www.figma.com/file/FoSC9J2tVjvjwt964XnRhD/StartApp-for-Startup?type=design&node-id=42-2&mode=design&t=vXalC7WGP37M0iO9-0
