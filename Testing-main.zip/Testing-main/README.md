# IT314 Software Engineering

## Group 27

### Course Project Testing Repository

This file contains the testing codes and documentations. 

1. Unit testing
2. Black box testing
3. Non-functional testing
4. GUI testing
5. Acceptance testing 
